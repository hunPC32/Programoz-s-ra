# ALL FUNCTION RETURN SOMETHING!

def circleArea(radius):
    # Write a Python function that calculates the area of a circle based on the radius entered by the user.
    return 0

def nameReverse(name):
    # Write a Python function that accepts the user's full name in hungarian style and prints them in reverse order with a space between them.
    return 0

def easyMath(n):
    # Write a Python function that accepts an integer (n) and computes the value of n+nn+nnn.
    return 0

def difference(num1,num2):
    # Write a Python function to calculate the difference between a two given number.
    return 0

def bmiIndex(weight, height):
    # Write a Python function to calculate the body mass index.
    return 0

def digitsSum(number):
    # Write a Python function to calculate sum of digits of a number.
    return 0

def sortThree(a,b,c):
    # Write a Python function to sort three integers without using conditional statements and loops (return list!).
    return 0

def bePositive(li):
    # Write a Python function to filter positive numbers from a list (return list!).
    return 0

def decimalToBinary(decimalNum):
    # Write a Python function to convert an integer (decimal) to binary (return string!).
    return 0

def decimalToHexa(decimalNum):
    # Write a Python function to convert decimal to hexadecimal (return string!).
    return 0